package com.samsung.taba7lite.edgelauncher.data

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import com.samsung.taba7lite.edgelauncher.service.AppLaunchMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * AppRepository
 * 
 * High-performance, low-RAM data layer:
 * - Queries PackageManager strictly on Dispatchers.IO
 * - LRU memory cache for application icons (capped at 12 MB)
 * - T9 telephone keypad match algorithm
 * - Multi-Window Intent launcher (FLAG_ACTIVITY_LAUNCH_ADJACENT + Freeform pop-up window)
 */
class AppRepository private constructor(private val context: Context) {

    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // LRU Memory Cache for app icons (Max 12MB out of Tab A7 Lite's 3GB RAM)
    private val iconCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(
        (12 * 1024 * 1024) // 12 Megabytes
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return value.byteCount
        }
    }

    private val _installedAppsFlow = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedAppsFlow: StateFlow<List<AppInfo>> = _installedAppsFlow.asStateFlow()

    private val _favoritePackageNames = MutableStateFlow<Set<String>>(
        setOf(
            "com.samsung.android.app.notes",
            "com.sec.android.app.sbrowser",
            "com.sec.android.app.camera",
            "com.sec.android.gallery3d",
            "com.android.settings",
            "com.sec.android.app.popupcalculator"
        )
    )
    val favoritePackageNames: StateFlow<Set<String>> = _favoritePackageNames.asStateFlow()

    init {
        reloadInstalledApps()
    }

    /**
     * Asynchronously loads all launchable apps
     */
    fun reloadInstalledApps() {
        repositoryScope.launch {
            val apps = withContext(Dispatchers.IO) {
                queryLaunchableApps()
            }
            _installedAppsFlow.value = apps
        }
    }

    private fun queryLaunchableApps(): List<AppInfo> {
        val packageManager = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(mainIntent, 0)
        }

        val appList = mutableListOf<AppInfo>()
        for (info in resolveInfos) {
            val packageName = info.activityInfo.packageName
            val activityName = info.activityInfo.name
            val appLabel = info.loadLabel(packageManager).toString()

            // Pre-calculate T9 numeric representation (e.g. "Samsung" -> "7267864")
            val t9Key = computeT9Digits(appLabel)

            appList.add(
                AppInfo(
                    packageName = packageName,
                    activityName = activityName,
                    appName = appLabel,
                    t9Key = t9Key,
                    isSystemApp = (info.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0,
                    isFavorite = _favoritePackageNames.value.contains(packageName)
                )
            )
        }

        // Sort alphabetically for fast A-Z index scroller
        return appList.sortedBy { it.appName.lowercase(Locale.ROOT) }
    }

    /**
     * Efficiently retrieves or generates a cached icon bitmap
     */
    suspend fun getAppIcon(appInfo: AppInfo, lowPowerMode: Boolean): Bitmap = withContext(Dispatchers.IO) {
        val cacheKey = "${appInfo.packageName}_${if (lowPowerMode) "low" else "high"}"
        val cached = iconCache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            return@withContext cached
        }

        val drawable: Drawable = try {
            context.packageManager.getApplicationIcon(appInfo.packageName)
        } catch (e: Exception) {
            context.packageManager.defaultActivityIcon
        }

        // On Tab A7 Lite low-RAM mode, downscale icon to 48x48dp to preserve cache space
        val targetSize = if (lowPowerMode) 48 else 72
        val bitmap = drawableToBitmap(drawable, targetSize, targetSize)
        iconCache.put(cacheKey, bitmap)
        bitmap
    }

    private fun drawableToBitmap(drawable: Drawable, widthDp: Int, heightDp: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val density = context.resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt().coerceAtLeast(1)
        val heightPx = (heightDp * density).toInt().coerceAtLeast(1)

        val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    /**
     * T9 Search & Instant Live Fuzzy Filter
     */
    fun filterApps(query: String): List<AppInfo> {
        val current = _installedAppsFlow.value
        if (query.isBlank()) return current

        val cleaned = query.trim().lowercase(Locale.ROOT)
        val isNumericT9 = cleaned.all { it.isDigit() }

        return current.filter { app ->
            if (isNumericT9) {
                app.t9Key.contains(cleaned) || app.appName.lowercase(Locale.ROOT).contains(cleaned)
            } else {
                app.appName.lowercase(Locale.ROOT).contains(cleaned) ||
                        app.packageName.lowercase(Locale.ROOT).contains(cleaned)
            }
        }
    }

    /**
     * Launches app in standard, Split-Screen (Launch Adjacent), or Freeform Pop-up
     */
    fun launchApp(appInfo: AppInfo, mode: AppLaunchMode) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName) ?: return

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        when (mode) {
            AppLaunchMode.NORMAL -> {
                context.startActivity(launchIntent)
            }

            AppLaunchMode.SPLIT_SCREEN -> {
                // Android standard multi-window FLAG_ACTIVITY_LAUNCH_ADJACENT
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

                val options = ActivityOptions.makeBasic()
                context.startActivity(launchIntent, options.toBundle())
            }

            AppLaunchMode.FREEFORM_POPUP -> {
                // Samsung Galaxy Tab A7 Lite One UI Freeform Pop-up Mode
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

                val options = ActivityOptions.makeBasic()
                try {
                    // Reflection invocation for Samsung One UI / Android 11+ Freeform windowing mode (WINDOWING_MODE_FREEFORM = 5)
                    val method = ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    method.invoke(options, 5) // WINDOWING_MODE_FREEFORM
                } catch (e: Exception) {
                    // Fallback to standard adjacent launch if vendor restricted
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                }

                context.startActivity(launchIntent, options.toBundle())
            }
        }
    }

    fun toggleFavorite(packageName: String) {
        val current = _favoritePackageNames.value.toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        _favoritePackageNames.value = current
        reloadInstalledApps()
    }

    companion object {
        @Volatile
        private var instance: AppRepository? = null

        fun getInstance(context: Context): AppRepository {
            return instance ?: synchronized(this) {
                instance ?: AppRepository(context.applicationContext).also { instance = it }
            }
        }

        private fun computeT9Digits(name: String): String {
            val sb = StringBuilder()
            for (ch in name.lowercase(Locale.ROOT)) {
                val digit = when (ch) {
                    'a', 'b', 'c' -> '2'
                    'd', 'e', 'f' -> '3'
                    'g', 'h', 'i' -> '4'
                    'j', 'k', 'l' -> '5'
                    'm', 'n', 'o' -> '6'
                    'p', 'q', 'r', 's' -> '7'
                    't', 'u', 'v' -> '8'
                    'w', 'x', 'y', 'z' -> '9'
                    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> ch
                    else -> continue
                }
                sb.append(digit)
            }
            return sb.toString()
        }
    }
}
