package com.samsung.taba7lite.edgelauncher.data

data class AppInfo(
    val packageName: String,
    val activityName: String,
    val appName: String,
    val t9Key: String,
    val isSystemApp: Boolean = false,
    val isFavorite: Boolean = false
)
