# App Launcher — Edge Sidebar & Quick Drawer
### Tailored for Samsung Galaxy Tab A7 Lite (SM-T220 / SM-T225)

## 1. Hardware & System Target Profile
- **SoC:** MediaTek MT8768T Helio P22T (8x Cortex-A53 up to 2.3 GHz).
- **GPU:** PowerVR GE8320 (Avoid heavy RenderScript blurs and complex alpha clipping).
- **RAM:** 3GB or 4GB LPDDR4x.
- **Display:** 8.7-inch TFT WXGA+ (1340 x 800 pixels, ~179 PPI, 5:3 aspect ratio).
- **OS:** Android 11 up to Android 14 (One UI Core 3.1 / 4.1 / 5.1 / 6.0).

---

## 2. Low-Resource Systems Architecture
1. **Zero Wake-Locks:** The overlay service `EdgeOverlayService` never retains `PowerManager.WakeLock`.
2. **LRU Icon Cache:** Memory footprint is strictly capped at 12 MB.
3. **No Background Polling:** Uses `PackageChangeReceiver` for `ACTION_PACKAGE_ADDED` and `ACTION_PACKAGE_REMOVED` broadcast events.
4. **Hardware Acceleration:** Native Android views with `WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED` ensure 60 FPS transitions without dropped frames.

---

## 3. Step-by-Step Physical Device Testing Guide

### Step 1: Enable Developer Options & USB Debugging
1. On your Galaxy Tab A7 Lite, open **Settings**.
2. Tap **About tablet** -> **Software information**.
3. Tap **Build number** 7 times until you see *"Developer mode has been enabled"*.
4. Go back to **Settings** -> **Developer options** -> Enable **USB debugging**.

### Step 2: Build & Install via ADB
```bash
# 1. Build debug APK
./gradlew assembleDebug

# 2. Install to connected Galaxy Tab A7 Lite
adb install -r app/build/outputs/apk/debug/app-debug.apk

# 3. Grant Overlay (SYSTEM_ALERT_WINDOW) via ADB command line
adb shell appops set com.samsung.taba7lite.edgelauncher SYSTEM_ALERT_WINDOW allow

# 4. Whitelist from One UI battery optimizations
adb shell dumpsys deviceidle whitelist +com.samsung.taba7lite.edgelauncher
```

### Step 3: Samsung One UI Core System Configuration
Because Samsung One UI Core aggressively kills background services on 3GB RAM devices:
1. Open **Settings** -> **Battery and device care** -> **Battery**.
2. Tap **Background usage limits**.
3. Tap **Never sleeping apps** -> Tap **+** and add **App Launcher**.
4. In **Settings** -> **Apps** -> **App Launcher** -> **Battery**, set to **Unrestricted**.

### Step 4: Verify Memory & Battery Benchmarks
```bash
# Check memory footprint (Target: < 40 MB)
adb shell dumpsys meminfo com.samsung.taba7lite.edgelauncher

# Verify zero wake locks
adb shell dumpsys batterystats | grep com.samsung.taba7lite.edgelauncher
```

---

## 4. Multi-Window Verification
